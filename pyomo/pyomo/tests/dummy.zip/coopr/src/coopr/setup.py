from setuptools import setup

setup(name='Coopr',
      version='1.0',
      maintainer='William E. Hart',
      maintainer_email='wehart@sandia.gov',
      url = 'https://software.sandia.gov/coopr',
      license = 'BSD',
      platforms = ["any"],
      description = 'Coopr: a COmmon Optimization Python Repository',
      classifiers = [
            'Development Status :: 4 - Beta',
            'Intended Audience :: End Users/Desktop',
            'Intended Audience :: Science/Research',
            'License :: OSI Approved :: BSD License',
            'Natural Language :: English',
            'Operating System :: Microsoft :: Windows',
            'Operating System :: Unix',
            'Programming Language :: Python',
            'Programming Language :: Unix Shell',
            'Topic :: Scientific/Engineering :: Mathematics',
            'Topic :: Software Development :: Libraries :: Python Modules'
        ],
      packages=['coopr', 'coopr.coopr'],
      keywords=['optimization'],
      namespace_packages=['coopr']
      )

